#include "Circle.h"
#include <cmath>


void circle::setRadius(double r){
    radius = r;
}
//setX
void circle::setX(double value){
    x = value;
}
//setY
void circle::setY(double value){
    y = value;
}

//getRadius function
double circle::getRadius() {
    return radius;
}

//getX function
double circle::getX(){
    return x;
}
//getY function
double circle::getY(){
    return y;
}

//getArea function
double circle::getArea(){
    return radius*radius*3.14;
}

// Check if point is within the circle
bool Circle::containsPoint(double xValue, double yValue) {
    double dx = xValue - x;
    double dy = yValue - y;
    double distance = sqrt(dx * dx + dy * dy);
    return distance <= radius;
}
