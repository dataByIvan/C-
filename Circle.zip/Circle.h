#include <iostream>
using namespace std;
#ifndef CIRCLE_H
#define CIRCLE_H

class circle{
    private:
        double radius;
        double x;
        double y;
        void setRadius(double r);
        void setX(double value);
        void setY(double value);
        double getRadius();
        double getX();
        double getY();
        
    public:
        void setValues(double r, double xVal, double yVal);
        double getArea();
        bool containsPoint(double xValue, double yValue);
};