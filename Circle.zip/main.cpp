#include <iostream>
#include "Circle.h"
using namespace std;

int main() {

    Circle* myCircle = new Circle();
    myCircle->setValues(20.0, 2.0, 3.0); // radius = 20, center at (2, 3)


    cout << "Area of the circle: " << myCircle->getArea() << endl;


    cout << "Does it contain point (2.0, 4.0)? ";
    cout << (myCircle->containsPoint(2.0, 4.0) ? "Yes" : "No") << endl;


    cout << "Does it contain point (2.0, 100.0)? ";
    cout << (myCircle->containsPoint(2.0, 100.0) ? "Yes" : "No") << endl;


    cout << "Does it contain point (2.0, 23.0)? ";
    cout << (myCircle->containsPoint(2.0, 23.0) ? "Yes" : "No") << endl;

    delete myCircle;
    return 0;
}

/*
Sample Output:
Area of the circle: 1256
Does it contain point (2.0, 4.0)? Yes
Does it contain point (2.0, 100.0)? No
Does it contain point (2.0, 23.0)? Yes
*/
